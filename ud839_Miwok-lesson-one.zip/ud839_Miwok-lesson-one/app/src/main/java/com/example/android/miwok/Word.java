package com.example.android.miwok;

import android.graphics.drawable.Drawable;

public class Word {
    private String mDefaultTranslation;
    private String mMiwokTranslation;
    private  int mImageResourseId;





    public int getmImageResourseId() {
        return mImageResourseId;
    }

    public void setmImageResourseId(int mImageResourseId) {
        this.mImageResourseId = mImageResourseId;
    }

    public String getmDefaultTranslation() {
        return mDefaultTranslation;
    }

    public String getmMiwokTranslation() {
        return mMiwokTranslation;
    }

    public Word(String defaultTranslation, String miwokTranslation, int imageResourseId){

        mDefaultTranslation = defaultTranslation;
        mMiwokTranslation = miwokTranslation;
        mImageResourseId = imageResourseId;


    }

    public Word(String defaultTranslation, String miwokTranslation){

        mDefaultTranslation = defaultTranslation;
        mMiwokTranslation = miwokTranslation;


    }

}
